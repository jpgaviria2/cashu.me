import{m as a,b7 as r}from"./index.7878d18b.js";function u(){return a(r)}export{u};
