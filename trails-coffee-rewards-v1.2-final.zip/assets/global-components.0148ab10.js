import{v as m}from"./index.7878d18b.js";import{i as o}from"./vue-qrcode.esm.fa4b9155.js";var e=m(async({app:a})=>{a.component(o.name,o)});export{e as default};
