import{x as e,j as s}from"./index.7878d18b.js";var c=e({name:"QSpace",setup(){const a=s("div",{class:"q-space"});return()=>a}});export{c as Q};
