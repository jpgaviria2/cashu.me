import{v as m}from"./index.7a188b2e.js";import{i as o}from"./vue-qrcode.esm.5330c890.js";var e=m(async({app:a})=>{a.component(o.name,o)});export{e as default};
