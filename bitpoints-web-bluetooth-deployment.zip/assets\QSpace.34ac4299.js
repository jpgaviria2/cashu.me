import{x as e,j as s}from"./index.7a188b2e.js";var c=e({name:"QSpace",setup(){const a=s("div",{class:"q-space"});return()=>a}});export{c as Q};
