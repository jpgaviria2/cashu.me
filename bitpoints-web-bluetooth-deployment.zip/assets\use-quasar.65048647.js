import{m as a,b7 as r}from"./index.7a188b2e.js";function u(){return a(r)}export{u};
