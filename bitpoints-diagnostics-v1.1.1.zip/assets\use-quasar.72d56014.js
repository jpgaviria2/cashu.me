import{m as a,b7 as r}from"./index.20404335.js";function u(){return a(r)}export{u};
