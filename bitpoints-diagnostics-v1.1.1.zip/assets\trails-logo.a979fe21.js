var s="/assets/trails-logo.1372c88a.png";export{s as _};
