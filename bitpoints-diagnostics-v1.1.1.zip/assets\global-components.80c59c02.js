import{v as m}from"./index.20404335.js";import{i as o}from"./vue-qrcode.esm.6052bf40.js";var e=m(async({app:a})=>{a.component(o.name,o)});export{e as default};
