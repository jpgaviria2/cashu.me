import{v as m}from"./index.b12a1bb3.js";import{i as o}from"./vue-qrcode.esm.43c113ab.js";var e=m(async({app:a})=>{a.component(o.name,o)});export{e as default};
