import{x as e,j as s}from"./index.b12a1bb3.js";var c=e({name:"QSpace",setup(){const a=s("div",{class:"q-space"});return()=>a}});export{c as Q};
