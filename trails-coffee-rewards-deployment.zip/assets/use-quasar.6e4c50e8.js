import{m as a,b8 as r}from"./index.b12a1bb3.js";function u(){return a(r)}export{u};
