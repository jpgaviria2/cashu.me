/**
 * Configures the Cashu-ts library axios client
 */
// import { setupAxios } from "@cashu/cashu-ts";

// export default () => {
//   setupAxios({
//     // Default timeout for any interaction using the cashu-ts library to interact with a mint
//     timeout: 15 * 1000, // 15 seconds
//   });
// };
