package me.cashu.wallet;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
